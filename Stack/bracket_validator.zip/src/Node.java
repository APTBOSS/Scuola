public class Node <G> {
    G dato;
    Node <G> next;

    public Node(G dato) {
        this.dato = dato;
        this.next = null;
    }
}
