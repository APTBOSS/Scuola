import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bracket_Validator bV = new Bracket_Validator();
        Scanner sc = new Scanner(System.in);

        System.out.println("Inserisci un'espressione algebrica");
        String espr = sc.nextLine();

        if(bV.balance_brackets(espr)) {
            System.out.println("✔ Le parentesi sono bilanciate.");
        } else {
            System.out.println("❌ Le parentesi NON sono bilanciate.");
        }

    }
}